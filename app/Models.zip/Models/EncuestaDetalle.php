<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EncuestaDetalle extends Model
{
	protected $table ='encuestas_detalle';
	public $primarykey='id';
	
	
}
