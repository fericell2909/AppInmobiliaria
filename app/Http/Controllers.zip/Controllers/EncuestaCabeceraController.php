<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EncuestaCabeceraController extends Controller
{
    //
}
